package com.eva.vtiger.pages.or.marketing.campaign;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OrCampaignLandingPage {

	@FindBy(xpath="//img[@alt='Create Campaign...']")
	protected WebElement campaignBt;
	
	
}
