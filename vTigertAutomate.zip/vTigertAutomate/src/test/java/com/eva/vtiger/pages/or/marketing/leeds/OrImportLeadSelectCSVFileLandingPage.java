package com.eva.vtiger.pages.or.marketing.leeds;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OrImportLeadSelectCSVFileLandingPage {

	@FindBy(xpath="//input[@type='file']")
	protected WebElement clickOnChooseFile;
	
	@FindBy(xpath="//input[@class='crmButton small save']")
	protected WebElement clickOnNextButton;
	
	@FindBy(xpath="//input[@class='crmButton small cancel']")
	protected WebElement clickOnCancelButton;
	
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
