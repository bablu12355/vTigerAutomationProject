package com.eva.vtiger.pages.or.marketing.campaign;

public class OrDeleteCampaignLandingPage {

}
