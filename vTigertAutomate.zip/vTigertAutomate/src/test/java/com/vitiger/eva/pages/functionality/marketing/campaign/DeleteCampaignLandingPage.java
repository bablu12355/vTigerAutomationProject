package com.vitiger.eva.pages.functionality.marketing.campaign;

public class DeleteCampaignLandingPage {

}
