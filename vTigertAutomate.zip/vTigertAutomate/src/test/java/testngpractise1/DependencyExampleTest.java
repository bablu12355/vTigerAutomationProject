package testngpractise1;

import org.testng.annotations.Test;

public class DependencyExampleTest {

  @Test
  public void driveCarTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void parkCarTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void startCarTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void stopCarTest() {
    throw new RuntimeException("Test not implemented");
  }
}
